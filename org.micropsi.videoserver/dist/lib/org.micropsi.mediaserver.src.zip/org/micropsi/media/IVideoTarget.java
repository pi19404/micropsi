package org.micropsi.media;

public interface IVideoTarget {
	
	public void start() throws Exception;
	
	public void stop() throws Exception;

}
