/*
 * $Header: G:\DEV\Workspace\migration3.0\micropsi-cvs-repository\micropsi/org.micropsi.core/sources/org/micropsi/common/utils/InteractiveClassLoaderIF.java,v 1.3 2004/11/24 16:15:55 vuine Exp $ 
 */
package org.micropsi.common.utils;


public interface InteractiveClassLoaderIF {
	// tag interface
}
