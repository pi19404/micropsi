/**
 * $Header: G:\DEV\Workspace\migration3.0\micropsi-cvs-repository\micropsi/org.micropsi.core/sources/org/micropsi/comp/common/TimeDispatcherIF.java,v 1.1 2005/01/20 23:24:56 vuine Exp $
 */
package org.micropsi.comp.common;


public interface TimeDispatcherIF {

	public void newTimeIs(long time);

}
