/**
 * $Header: /srv/cvsroot/micropsi/org.micropsi.core/sources/org/micropsi/common/communication/ComChannelTypesIF.java,v 1.3 2005/06/02 02:04:20 vuine Exp $
 */
package org.micropsi.common.communication;

public interface ComChannelTypesIF {
	
	public static final int CHANNELTYPE_LOCAL = 0;
	public static final int CHANNELTYPE_XML	= 1;
	public static final int CHANNELTYPE_XML_DEBUG = 100;
	
}
