/*
 * Created on 21.12.2004
 *
 */
package org.micropsi.comp;

import org.micropsi.common.coordinates.WorldVector;

/**
 * @author Markus
 *
 */
public class Functions {
    
    /**
     * @param vector
     * @return the angle between vector and (1,0,0)
     */
    public static double getAngle(WorldVector vector) {
        double length = vector.getLength();
        double y = Math.abs(vector.getY());
        double angle = Math.toDegrees(Math.asin(y / length));
        
        if (vector.getX() < 0)
            angle = 180.0 - angle;
        if (vector.getY() < 0)
            angle *= -1.0;
            
        return angle;
    }
    
    public static int min(int v1, int v2) {
        return (v1 < v2) ? v1 : v2;
    }
}
