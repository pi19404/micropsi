/*
 * Created on 10.05.2005
 *
 */
package org.micropsi.comp.agent.percepts;

import org.micropsi.comp.agent.MouseMicroPsiAgent;
import org.micropsi.nodenet.SensorDataSourceIF;

/**
 * @author Markus
 *
 */
public class PerceptPoison implements SensorDataSourceIF {

	private String dataType = new String("poison");
	private MouseMicroPsiAgent agent;
	private double signalStrength;

	public PerceptPoison(MouseMicroPsiAgent micropsi) {
		this.agent = micropsi;
	}
	
	public String getDataType() {
		return dataType;
	}

//	TODO relative to worldsize
	public double getSignalStrength() {
	    return signalStrength;
	}
	
	public void setSignalStrength(double signal) {
	    signalStrength = signal;
	}
}


