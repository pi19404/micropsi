/*
 * Created on 20.05.2005
 *
 */
package org.micropsi.comp.agent.actions;

import org.apache.log4j.Logger;
import org.micropsi.comp.agent.MouseMicroPsiAgent;
import org.micropsi.comp.agent.aaa.ActionTranslatorIF;
import org.micropsi.comp.agent.micropsi.actions.ActionDataTarget;
import org.micropsi.comp.messages.MAction;
import org.micropsi.nodenet.LocalNetFacade;
import org.micropsi.nodenet.NetFacadeIF;
import org.micropsi.nodenet.agent.SituationElement;

/**
 * @author Markus
 *
 */
public class SmileAction implements ActionTranslatorIF {

    private static final String actionID = "SMILE";
    private	NetFacadeIF net;
    private ActionDataTarget smile;
    private MAction smileAction;
    private MouseMicroPsiAgent agent;
    private Logger logger;
    
    public SmileAction(LocalNetFacade net, MouseMicroPsiAgent agent, Logger logger) {
        this.net = net;
        this.agent = agent;
        this.logger = logger;
        smile = new ActionDataTarget("smile");
        net.getSensorRegistry().registerActuatorDataTarget(smile);
		net.getCycle().registerCycleObserver(smile);
        smileAction = new MAction(actionID, "");
    }

    public String getActionID() {
        return actionID;
    }

    public double getCurrentActionPriority() {
        return smile.getSignalStrength();
    }

    public MAction calculateAction() {
        getPartner();
        SituationElement attention = agent.getSituation().getElementInFovea();
		if(attention != null) {
			smileAction.setTargetObject(attention.getWorldID());
		} else {
			smileAction.setTargetObject(-1);
		}
		
		smile.quiet();
		smile.confirmActionExecution();
		
		return smileAction;
    }

    // sets the attention on agent in range
    private void getPartner() {
        
    }
    
    public void dontCalculateAction() {
        smile.quiet();
    }

    public void receiveActionResult(double value) {
        smile.setSuccess(value);
    }

    public void shutdown() {
        ((LocalNetFacade)net).getSensorRegistry().registerActuatorDataTarget(smile);
    }
}
