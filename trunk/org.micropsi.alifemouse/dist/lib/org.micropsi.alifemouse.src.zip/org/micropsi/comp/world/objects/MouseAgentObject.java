/*
 * Created on 09.04.2005
 *
 */
package org.micropsi.comp.world.objects;

import java.util.Iterator;

import org.micropsi.common.coordinates.Position;
import org.micropsi.common.coordinates.WorldVector;
import org.micropsi.comp.ConstantValues;
import org.micropsi.comp.messages.MAction;
import org.micropsi.comp.messages.MActionResponse;
import org.micropsi.comp.messages.MPercept;
import org.micropsi.comp.messages.MPerceptionResp;
import org.micropsi.comp.messages.MPerceptionValue;
import org.micropsi.comp.world.messages.AbstractWorldMessage;
import org.micropsi.comp.world.messages.WorldMessage;

/**
 * @author Markus
 *
 */
public class MouseAgentObject extends SteamVehicleAgentObject {
    private int obstacle = 0;
    private int poison = 0;
    private int food = 0;
    private int water = 0;
    private int healing = 0;
    
    private WorldVector orientationVector = new WorldVector(0.0, 1.0, 0.0);
    private double speedLimit = 1;
	private double wheelDistance = 1;
    
    public MouseAgentObject(String objectName, String objectClass, Position pos) {
        super(objectName, objectClass, new Position(45.0, 35.0, 0.0));
    }
    
    public MouseAgentObject(String objectName, Position pos) {
		this(objectName, "MouseAgent", pos);
	}
    
    // set visionRange
	protected void initObjectParameters() {
		super.initObjectParameters();
		visionRange = ConstantValues.PERCEPTION_RANGE;
	}
	
	public MPerceptionResp getPerception() {
		MPerceptionResp perception = new MPerceptionResp();
		
		Iterator it = getVisibleObjects().iterator();
		while (it.hasNext()) {
		    AbstractObject object = (AbstractObject) it.next();
			MPercept percept = new MPercept("OBJECT");
			percept.addParameter("ID", Long.toString(object.getId()));
			percept.addParameter("CLASS", object.getObjectClass());

			Position p = new Position(object.getPosition());
			/*
			p.subtract(this.getPosition());
			WorldVector temp = new WorldVector(p.getX(), p.getY(), p.getZ());
			double relativeAngle = Functions.getAngle(orientationVector);
			temp.rotate(relativeAngle);
			p = new Position(temp.getX(), temp.getY(), temp.getZ());
			*/
			percept.addParameter("POSITION", p.toString());
			percept.addParameter("AGENTPOSITION", this.position.toString());
			percept.addParameter("AGENTID", Long.toString(this.id));
			
			perception.addPercept(percept);
		}
		return perception;
	}
	
	protected void addBodyPropertyChanges(MActionResponse actionResp) {
		actionResp.addBodyPropertyChange(
		        new MPerceptionValue("XPOSITION", Double.toString(this.getPosition().getX())));
		actionResp.addBodyPropertyChange(
		        new MPerceptionValue("YPOSITION", Double.toString(this.getPosition().getY())));
		actionResp.addBodyPropertyChange(
		        new MPerceptionValue("ORIENTATION", Double.toString(this.getOrientationAngle() / 360.0)));
		actionResp.addBodyPropertyChange(
				new MPerceptionValue("OBSTACLE", Integer.toString(obstacle)));
		actionResp.addBodyPropertyChange(
				new MPerceptionValue("POISON", Integer.toString(poison)));
		actionResp.addBodyPropertyChange(
				new MPerceptionValue("FOOD", Integer.toString(food)));
		actionResp.addBodyPropertyChange(
				new MPerceptionValue("WATER", Integer.toString(water)));
		actionResp.addBodyPropertyChange(
				new MPerceptionValue("HEALING", Integer.toString(healing)));
	}
	
	public void handleAction(MAction action, AbstractObjectPart targetObject) {
	    super.handleAction(action, targetObject);
	    if (action.getActionType().equals("WALK")) {
	        double direction = new Double(action.getParameter(0)).doubleValue();
	        double forward = new Double(action.getParameter(1)).doubleValue();
	        double success = 0;
	        
	        WorldVector newOrientationVector = new WorldVector(0.0, 1.0, 0.0);
	        newOrientationVector.rotate(direction * 360);
	        
	        orientationVector = newOrientationVector;
	        
	        WorldVector effortVec = new WorldVector(orientationVector.getX(),orientationVector.getY(),orientationVector.getZ());
	        effortVec.scaleBy(forward);
	        
	        // sensor infos
	        Position testPosition = new Position(this.position);
	        testPosition.add(effortVec);
	        if(world.getGroundType(testPosition).isAgentAllowed())
	            obstacle = 0;
	        else
	            obstacle = 1;
	        if(world.getGroundType(testPosition).getName().equals("swamp"))
	            poison = 1;
	        else
	            poison = 0;
	        
	        WorldVector moveVec = world.getEffectiveMoveVector(this, effortVec);
			if (Math.abs(effortVec.getLength() - moveVec.getLength()) < 0.001) {
				// condition temporary: agent should for now only get to discreet positions
				moveBy(effortVec); // should be moveVec later
				success = 1.0;
			} else {
				success = -1.0;
			}
			
			if(world.getGroundType(testPosition).getName().equals("grass"))
	            food = 1;
	        else
	            food = 0;
			if(world.getGroundType(testPosition).getName().equals("shallowwater"))
	            water = 1;
	        else
	            water = 0;
			if(world.getGroundType(testPosition).getName().equals("darkgrass"))
	            healing = 1;
	        else
	            healing = 0;
			
	        MActionResponse actionResp = new MActionResponse(getAgentName(), success, action.getTicket());
			addBodyPropertyChanges(actionResp);		
			addActionAnswer(actionResp); 
			return;
	    }
	    
	    double success = -1;
	    if (action.getActionType().equals("MOVEBY")) {
	        double speedLeftWheel = Double.parseDouble(action.getParameter(0));
			double speedRightWheel = Double.parseDouble(action.getParameter(1));
			if (speedLeftWheel + speedRightWheel > 2*speedLimit) { // speed limit ;-)
				double fak = 2*speedLimit / (speedLeftWheel + speedRightWheel);
				speedLeftWheel *= fak;
				speedRightWheel *= fak;
			}
			moveAStep(speedLeftWheel, speedRightWheel);
			success = 1;	  
			
			MActionResponse actionResp = new MActionResponse(
					getAgentName(),
					success,
					action.getTicket()				
			);
			addBodyPropertyChanges(actionResp);
			
			addActionAnswer(actionResp);
	    }
	    if(action.getActionType().equals("SMILE")) {
	        //TODO find appropiate agent
	        AbstractObjectPart targetAgent = null;
	        AbstractWorldMessage m = new WorldMessage("AGENTACTION", "SMILE", this);
	        world.getPostOffice().send(m, targetAgent);
	    }
	    if(action.getActionType().equals("BITE")) {
	        //TODO find appropiate agent
	        AbstractObjectPart targetAgent = null;
	        AbstractWorldMessage m = new WorldMessage("AGENTACTION", "BITE", this);
	        world.getPostOffice().send(m, targetAgent);
	    }
	}
	
	public void _handleAction(AbstractWorldMessage message) {
	    // TODO adjust friend/foe
	    super._handleMessage(message);
	    if (message.isClass("AGENTACTION")) {
	        if (message.isContent("SMILE")) {
	          message.answer(new WorldMessage("ACTIONRESPONSE", "SMILE_RECEIVED", this));
	        } else if (message.isContent("BITE")){
	            message.answer(new WorldMessage("ACTIONRESPONSE", "GOT_BITTEN", this)); 
	        }
	    }
	    
	    if(message.isClass("ACTIONRESPONSE")) {
	        if(message.isContent("SMILE_RECEIVED")) {
	            
	        } else if(message.isContent("GOT_BITTEN")) {
	            
	        }
	    }
	}
	
	protected void moveAStep(double speedLeftWheel, double speedRightWheel) {
		double rotationAngle = Math.toDegrees(speedLeftWheel - speedRightWheel) / wheelDistance;
		WorldVector effortVec = new WorldVector(0, (speedRightWheel + speedLeftWheel) / 2, 0);
		effortVec.rotate(getOrientationAngle() + rotationAngle / 2);
		Position testPosition = new Position(this.position);
        testPosition.add(effortVec);
        if(world.getGroundType(testPosition).isAgentAllowed())
            obstacle = 0;
        else
            obstacle = 1;
        if(world.getGroundType(testPosition).getName().equals("swamp"))
            poison = 1;
        else
            poison = 0;
		moveBy(world.getEffectiveMoveVector(this, effortVec));
		rotateBy(rotationAngle);
		if(world.getGroundType(testPosition).getName().equals("grass"))
            food = 1;
        else
            food = 0;
		if(world.getGroundType(testPosition).getName().equals("shallowwater"))
            water = 1;
        else
            water = 0;
		if(world.getGroundType(testPosition).getName().equals("darkgrass"))
            healing = 1;
        else
            healing = 0;
	}
	/*
	public double getOrientationAngle() {
		return Functions.getAngle(orientationVector);
	}
	*/
	private void rotateRadians(double radians) {
		double oldx = orientationVector.getX();
		double oldy = orientationVector.getY();
		double x = oldx*Math.cos(radians) + oldy*Math.sin(radians);
		double y = -oldx*Math.sin(radians) + oldy*Math.cos(radians);
		orientationVector.set(x, y, orientationVector.getZ());
	}
}
