/*
 * Created on 21.04.2005
 *
 */
package org.micropsi.comp.agent;

import org.micropsi.comp.ConstantValues;

/**
 * @author Markus
 *
 */
public class AgentManager {
    private static AgentManager instance = null;
    
    private MouseMicroPsiAgent[] agents;
    
    public static synchronized AgentManager getInstance() {
        if(instance == null)
            instance = new AgentManager();
        return instance;
    }
    
    private AgentManager() {
        agents = new MouseMicroPsiAgent[ConstantValues.MAX_AGENT_COUNT];
        for(int i = 0; i < ConstantValues.MAX_AGENT_COUNT; i++) {
            agents[i] = null;
        }
    }

    public void addAgent(MouseMicroPsiAgent agent) {
        boolean inserted = false;
        for(int i = 0; i < ConstantValues.MAX_AGENT_COUNT; i++) {
            if(agents[i] == null) {
                agents[i] = agent;
                inserted = true;
                break;
            }
        }
        if(!inserted)
            System.err.println("AgentManager: could not insert agent; array is full");
    }
    
    public void deleteAgent(MouseMicroPsiAgent agent) {
        long ID = agent.getID();
        for(int i = 0; i < ConstantValues.MAX_AGENT_COUNT; i++) {
            if(agents[i] != null) {
	            if(agents[i].getID() == ID)
	                agents[i] = null;
	            else {
	                agents[i].deleteAgentFromKnownAgents(ID);
	            }
            }
        }
    }
}
