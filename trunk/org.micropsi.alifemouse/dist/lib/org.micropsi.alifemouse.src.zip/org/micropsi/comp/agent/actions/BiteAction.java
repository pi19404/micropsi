/*
 * Created on 20.05.2005
 *
 */
package org.micropsi.comp.agent.actions;

import org.apache.log4j.Logger;
import org.micropsi.comp.agent.MouseMicroPsiAgent;
import org.micropsi.comp.agent.aaa.ActionTranslatorIF;
import org.micropsi.comp.agent.micropsi.actions.ActionDataTarget;
import org.micropsi.comp.messages.MAction;
import org.micropsi.nodenet.LocalNetFacade;
import org.micropsi.nodenet.NetFacadeIF;
import org.micropsi.nodenet.agent.SituationElement;

/**
 * @author Markus
 *
 */
public class BiteAction implements ActionTranslatorIF {

    private static final String actionID = "BITE";
    private	NetFacadeIF net;
    private ActionDataTarget bite;
    private MAction biteAction;
    private MouseMicroPsiAgent agent;
    private Logger logger;
    
    public BiteAction(LocalNetFacade net, MouseMicroPsiAgent agent, Logger logger) {
        this.net = net;
        this.agent = agent;
        this.logger = logger;
        bite = new ActionDataTarget("bite");
        net.getSensorRegistry().registerActuatorDataTarget(bite);
		net.getCycle().registerCycleObserver(bite);
        biteAction = new MAction(actionID, "");
    }

    public String getActionID() {
        return actionID;
    }

    public double getCurrentActionPriority() {
        return bite.getSignalStrength();
    }

    public MAction calculateAction() {
        getPartner();
        SituationElement attention = agent.getSituation().getElementInFovea();
		if(attention != null) {
			biteAction.setTargetObject(attention.getWorldID());
		} else {
			biteAction.setTargetObject(-1);
		}
		
		bite.quiet();
		bite.confirmActionExecution();
		
		return biteAction;
    }

    // sets the attention on agent in range
    private void getPartner() {
        
    }
    
    public void dontCalculateAction() {
        bite.quiet();
    }

    public void receiveActionResult(double value) {
        bite.setSuccess(value);
    }

    public void shutdown() {
        ((LocalNetFacade)net).getSensorRegistry().registerActuatorDataTarget(bite);
    }
}