/*
 * Created on 09.04.2005
 *
 */
package org.micropsi.comp;

/**
 * @author Markus
 *
 */
public class ConstantValues {
    // BodySimulator
    public static final double HEALING_RATE = 0.5;
    public static final double FOOD_DECAY = 0.05;
    public static final int MAX_FOOD = 100;
    public static final int MAX_WATER = 100;
    public static final double INTERACTION_RANGE = 4.0;
    
    public static final double PERCEPTION_ANGLE = 360.0;
    public static final double PERCEPTION_RANGE = 20.0;
    
    public static final int MAX_AGENT_COUNT = 20;
    
    // world
    public static final double WORLDMAXX = 100.0;
    public static final double WORLDMAXY = 100.0;
    
    // nodenets
    public static final double STUBBORNESS = 0.2;
}
