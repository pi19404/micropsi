/*
 * Created on 28.04.2005
 *
 */
package org.micropsi.nodenet.modules;

import java.util.ArrayList;

import org.micropsi.common.coordinates.Position;
import org.micropsi.common.coordinates.WorldVector;
import org.micropsi.nodenet.AbstractNativeModuleImpl;
import org.micropsi.nodenet.ConceptNode;
import org.micropsi.nodenet.GateManipulator;
import org.micropsi.nodenet.GateTypesIF;
import org.micropsi.nodenet.Link;
import org.micropsi.nodenet.NetIntegrityException;
import org.micropsi.nodenet.Slot;
import org.micropsi.nodenet.SlotTypesIF;
import org.micropsi.nodenet.agent.TypeStrings;
import org.micropsi.nodenet.agent.TypeStringsExtensionIF;
import org.micropsi.nodenet.ext.StandardDecays;

/**
 * @author Markus
 *
 */
public class ProtocolModule extends AbstractNativeModuleImpl {

    //	slots
	private static final int XCOORDINATE  = 19500;
	private static final int YCOORDINATE  = 19501;
	private static final int FOODURGE	  = 19502;
	private static final int WATERURGE    = 19503;
	private static final int HEALINGURGE  = 19504;
	private static final int HURTBYGROUND = 19505;
	private static final int OBSTACLE     = 19506;
	private static final int NOPROTOCOL   = 19507;
	
	private static final int FOODCONCEPT = 19500;
	private static final int WATERCONCEPT = 19501;
	private static final int HEALINGCONCEPT = 19502;
	private static final int HURTCONCEPT = 19503;
	private static final int OBSTACLECONCEPT = 19504;
	
	private Slot x;
	private Slot y;
	private Slot food;
	private Slot water;
	private Slot healing;
	private Slot hurt;
	private Slot obstacle;
	private Slot noprotocol;
	
	private String lastNode = null;
	private String foodConcept = null;
	private String waterConcept = null;
	private String healingConcept = null;
	private String damageConcept = null;
	private String obstacleConcept = null;
	
	private boolean firsttime = true;
	private Position lastInsertedDamage = null;
	private Position lastInsertedObstacle = null;
	
	private final int[] slotTypes = {
	        XCOORDINATE,
	        YCOORDINATE,
	        FOODURGE,
	        WATERURGE,
	        HEALINGURGE,
	        HURTBYGROUND,
			OBSTACLE,
			NOPROTOCOL
		};
	
	private final int[] gateTypes = {
			FOODCONCEPT,
			WATERCONCEPT,
			HEALINGCONCEPT,
			HURTCONCEPT,
			OBSTACLECONCEPT
	};
	
	public ProtocolModule() {	
		TypeStrings.activateExtension(new TypeStringsExtensionIF() {

			private static final String id = "protocol";

			public String getExtensionID() {
				return id;
			}

			public String gateType(int type) {
			    switch(type) {
			    	case FOODCONCEPT: return "food-concept";
			    	case WATERCONCEPT: return "water-concept";
			    	case HEALINGCONCEPT: return "healing-concept";
			    	case HURTCONCEPT: return "damage-concept";
			    	case OBSTACLECONCEPT: return "obstacle-concept";
			    	default: return null;
			    }
			}

			public String slotType(int type) {
				switch(type) {
					case XCOORDINATE:	return "x-position";
					case YCOORDINATE:	return "y-position";
					case FOODURGE:		return "food-found";
					case WATERURGE:		return "water-found";
					case HEALINGURGE:	return "healing-found";
					case HURTBYGROUND:	return "got-hurt";
					case OBSTACLE:		return "obstacle";
					case NOPROTOCOL:	return "no-protocolling";
					default:			return null;
				}
			}
		});		
	}
	
    /* (non-Javadoc)
     * @see org.micropsi.nodenet.AbstractNativeModuleImpl#getGateTypes()
     */
    protected int[] getGateTypes() {
        // TODO Auto-generated method stub
        return gateTypes;
    }

    /* (non-Javadoc)
     * @see org.micropsi.nodenet.AbstractNativeModuleImpl#getSlotTypes()
     */
    protected int[] getSlotTypes() {
        return slotTypes;
    }
    
    private void catchSlots(Slot[] slots) {
		for (int i = 0; i < slots.length; i++) {
			switch (slots[i].getType()) {
				case XCOORDINATE :
					x = slots[i];
					break;
				case YCOORDINATE : 
					y = slots[i];
					break;
			    case FOODURGE :
			        food = slots[i];
			        break;
			    case WATERURGE :
			        water = slots[i];
			        break;
			    case HEALINGURGE :
			        healing = slots[i];
			        break;
			    case HURTBYGROUND :
			        hurt = slots[i];
			        break;
			    case OBSTACLE :
			    	obstacle =slots[i];
			    	break;
			    case NOPROTOCOL :
			    	noprotocol = slots[i];
			    	break;
			}
		}
	}

    /* (non-Javadoc)
     * @see org.micropsi.nodenet.AbstractNativeModuleImpl#calculate(org.micropsi.nodenet.Slot[], org.micropsi.nodenet.GateManipulator, long)
     */
    public void calculate(Slot[] slots, GateManipulator manipulator, long netstep) throws NetIntegrityException {
        if (firsttime) {
			catchSlots(slots);
			firsttime = false;
			
			Link l = manipulator.getGate(FOODCONCEPT).getLinkAt(0);
			if(l == null)
				logger.warn("protocol has no link to foodconcept");
			else
				foodConcept = l.getLinkedEntityID();
			
			l = manipulator.getGate(WATERCONCEPT).getLinkAt(0);
			if(l == null)
				logger.warn("protocol has no link to waterconcept");
			else
				waterConcept = l.getLinkedEntityID();
			
			l = manipulator.getGate(HEALINGCONCEPT).getLinkAt(0);
			if(l == null)
				logger.warn("protocol has no link to healingconcept");
			else
				healingConcept = l.getLinkedEntityID();
			
			l = manipulator.getGate(HURTCONCEPT).getLinkAt(0);
			if(l == null)
				logger.warn("protocol has no link to damageconcept");
			else
				damageConcept = l.getLinkedEntityID();
			
			l = manipulator.getGate(OBSTACLECONCEPT).getLinkAt(0);
			if(l == null)
				logger.warn("protocol has no link to obstacleconcept");
			else
				obstacleConcept = l.getLinkedEntityID();
		}
        
        double xposition = x.getIncomingActivation();
        double yposition = y.getIncomingActivation();
        String newNode;
        String newX;
        String newY;
        
        if(noprotocol.getIncomingActivation() < 0.5) {
	        if(lastNode != null) {
	            decayProtocol();
	            Link xLink = structure.findEntity(lastNode).getLink(GateTypesIF.GT_SUB, 0);
	            Link yLink = structure.findEntity(lastNode).getLink(GateTypesIF.GT_SUB, 1);
	            if(xLink != null && yLink != null) {
	                if(xLink.getWeight() == xposition && yLink.getWeight() == yposition) {
	                	// no movement
	                } else {
	                	double weight = 1.0;
		                newNode = structure.createConceptNode("pos " + xposition + ":" + yposition);
		                newX = structure.createConceptNode("x");
		                newY = structure.createConceptNode("y");
		                structure.createLink(newNode, GateTypesIF.GT_SUB, newX, SlotTypesIF.ST_GEN, xposition, 1.0);
		                structure.createLink(newNode, GateTypesIF.GT_SUB, newY, SlotTypesIF.ST_GEN, yposition, 1.0);
		                structure.createLink(newX, GateTypesIF.GT_SUR, newNode, SlotTypesIF.ST_GEN, xposition, 1.0);
		                structure.createLink(newY, GateTypesIF.GT_SUR, newNode, SlotTypesIF.ST_GEN, yposition, 1.0);
		                // test if node deletion is necessary
		                if(structure.findEntity(lastNode).getFirstLinkAt(GateTypesIF.GT_RET) != null) {
		                    String beforeLastNode = structure.findEntity(lastNode).getFirstLinkAt(GateTypesIF.GT_RET).getLinkedEntity().getID();
		                    Position beforeLastPos = NodeFunctions.getPosition(structure.findEntity(beforeLastNode));
		                    Position lastPos = NodeFunctions.getPosition(structure.findEntity(lastNode));
		                    Position newPos = NodeFunctions.getPosition(structure.findEntity(newNode));
		                    // test if node is not in static protocol
		                    if(structure.findEntity(lastNode).getFirstLinkAt(GateTypesIF.GT_SUR) == null) {
			                    // node-distance is less than threshold
			                    if(beforeLastPos.distance2D(newPos) < 3.0) {
			                        WorldVector vec1 = new WorldVector(lastPos.getX() - beforeLastPos.getX(), lastPos.getY() - beforeLastPos.getY());
			                        WorldVector vec2 = new WorldVector(newPos.getX() - lastPos.getX(), newPos.getY() - lastPos.getY());
			                        double angleDifference = Math.abs((vec1.getAngle() - vec2.getAngle()) % 360.0);
			                        if (angleDifference < 5.0) {
			                        	weight = (weight + structure.findEntity(lastNode).getFirstLinkAt(GateTypesIF.GT_RET).getWeight()) / 2.0;
			                            deleteNode(lastNode);
			                            lastNode = beforeLastNode;
			                        }
			                    }
		                    }
		                }
		                
		                structure.createLink(lastNode, GateTypesIF.GT_POR, newNode, SlotTypesIF.ST_GEN, 1.0, 1.0);
		                // double-linked
		                //TODO decay evolvable?
		                structure.getGateManipulator(newNode).setGateDecayType(GateTypesIF.GT_RET, StandardDecays.DT_AVERAGE_LINEAR);
		
		                structure.createLink(newNode, GateTypesIF.GT_RET, lastNode, SlotTypesIF.ST_GEN, weight, 1.0);
		                
		                lastNode = newNode;
	                }
	            }
	        } else {
	            newNode = this.structure.createConceptNode("pos " + xposition + ":" + yposition);
	            newX = this.structure.createConceptNode("x");
	            newY = this.structure.createConceptNode("y");
	            
	            structure.createLink(newNode, GateTypesIF.GT_SUB, newX, SlotTypesIF.ST_GEN, xposition, 1.0);
	            structure.createLink(newNode, GateTypesIF.GT_SUB, newY, SlotTypesIF.ST_GEN, yposition, 1.0);
	            
	            lastNode = newNode;
	        }
	        
	        double threshold = 0.0;
	        String oldNode;
	        // protocol events
	        if(food.getIncomingActivation() > 0.0) {
	        	oldNode = lastNode;
	            structure.createLink(foodConcept, GateTypesIF.GT_SUB, lastNode, SlotTypesIF.ST_GEN, 1.0, 1.0);
	            structure.createLink(lastNode, GateTypesIF.GT_SUR, foodConcept, SlotTypesIF.ST_GEN, 1.0, 1.0);
	            
	            threshold = 1.0 - food.getIncomingActivation();
	            if (structure.findEntity(lastNode).getFirstLinkAt(GateTypesIF.GT_RET) != null) {
		            String currentNode = structure.findEntity(lastNode).getFirstLinkAt(GateTypesIF.GT_RET).getLinkedEntityID();
		            
		            while (structure.findEntity(currentNode).getFirstLinkAt(GateTypesIF.GT_RET).getWeight() >= threshold) {
		                structure.createLink(foodConcept, GateTypesIF.GT_SUB, currentNode, SlotTypesIF.ST_GEN, 1.0, 1.0);
		                structure.createLink(currentNode, GateTypesIF.GT_SUR, foodConcept, SlotTypesIF.ST_GEN, 1.0, 1.0);
		                                
		                structure.getGateManipulator(oldNode).setGateDecayType(GateTypesIF.GT_RET, StandardDecays.NO_DECAY);
		                oldNode = currentNode;
		                currentNode = structure.findEntity(currentNode).getFirstLinkAt(GateTypesIF.GT_RET).getLinkedEntityID();
		                if(structure.findEntity(currentNode).getFirstLinkAt(GateTypesIF.GT_RET) == null)
		                    break;	                
		            }
	            }
	        }
	        if(water.getIncomingActivation() > 0.0) {
	        	oldNode = lastNode;
	            structure.createLink(waterConcept, GateTypesIF.GT_SUB, lastNode, SlotTypesIF.ST_GEN, 1.0, 1.0);
	            structure.createLink(lastNode, GateTypesIF.GT_SUR, waterConcept, SlotTypesIF.ST_GEN, 1.0, 1.0);
	            
	            threshold = 1.0 - water.getIncomingActivation();
	            if (structure.findEntity(lastNode).getFirstLinkAt(GateTypesIF.GT_RET) != null) {
		            String currentNode = structure.findEntity(lastNode).getFirstLinkAt(GateTypesIF.GT_RET).getLinkedEntityID();
		            
		            while (structure.findEntity(currentNode).getFirstLinkAt(GateTypesIF.GT_RET).getWeight() >= threshold) {
		                structure.createLink(waterConcept, GateTypesIF.GT_SUB, currentNode, SlotTypesIF.ST_GEN, 1.0, 1.0);
		                structure.createLink(currentNode, GateTypesIF.GT_SUR, waterConcept, SlotTypesIF.ST_GEN, 1.0, 1.0);
		                
		                structure.getGateManipulator(oldNode).setGateDecayType(GateTypesIF.GT_RET, StandardDecays.NO_DECAY);
		                oldNode = currentNode;
		                currentNode = structure.findEntity(currentNode).getFirstLinkAt(GateTypesIF.GT_RET).getLinkedEntityID();
		                if(structure.findEntity(currentNode).getFirstLinkAt(GateTypesIF.GT_RET) == null)
		                    break;	                
		            }
	            }
	        }
	        if(healing.getIncomingActivation() > 0.0) {
	        	oldNode = lastNode;
	            structure.createLink(healingConcept, GateTypesIF.GT_SUB, lastNode, SlotTypesIF.ST_GEN, 1.0, 1.0);
	            structure.createLink(lastNode, GateTypesIF.GT_SUR, healingConcept, SlotTypesIF.ST_GEN, 1.0, 1.0);
	            
	            threshold = 1.0 - healing.getIncomingActivation();
	            if (structure.findEntity(lastNode).getFirstLinkAt(GateTypesIF.GT_RET) != null) {
		            String currentNode = structure.findEntity(lastNode).getFirstLinkAt(GateTypesIF.GT_RET).getLinkedEntityID();
		            
		            while (structure.findEntity(currentNode).getFirstLinkAt(GateTypesIF.GT_RET).getWeight() >= threshold) {
		                structure.createLink(healingConcept, GateTypesIF.GT_SUB, currentNode, SlotTypesIF.ST_GEN, 1.0, 1.0);
		                structure.createLink(currentNode, GateTypesIF.GT_SUR, healingConcept, SlotTypesIF.ST_GEN, 1.0, 1.0);
		                
		                structure.getGateManipulator(oldNode).setGateDecayType(GateTypesIF.GT_RET, StandardDecays.NO_DECAY);
		                oldNode = currentNode;
		                currentNode = structure.findEntity(currentNode).getFirstLinkAt(GateTypesIF.GT_RET).getLinkedEntityID();
		                if(structure.findEntity(currentNode).getFirstLinkAt(GateTypesIF.GT_RET) == null)
		                    break;
		            }
	            }
	        }
        }
        if(hurt.getIncomingActivation() > 0.0) {
            addDamageNode(lastNode);
        }
        
        if(obstacle.getIncomingActivation() > 0.0) {
        	addObstacleNode(lastNode);
        }
    }
    
    private void decayProtocol() {
        String currentNode = lastNode;
        ArrayList toDelete = new ArrayList();      
        while(structure.findEntity(currentNode).getFirstLinkAt(GateTypesIF.GT_RET) != null) {
        	try {
				structure.findEntity(currentNode).updateDecayState();
			} catch (NetIntegrityException e) {
				e.printStackTrace();
			}
            if(structure.findEntity(currentNode).getFirstLinkAt(GateTypesIF.GT_RET) != null && structure.findEntity(currentNode).getFirstLinkAt(GateTypesIF.GT_RET).getWeight() < 0.5) {
                String linkedNode = structure.findEntity(currentNode).getFirstLinkAt(GateTypesIF.GT_RET).getLinkedEntityID();
                if(structure.findEntity(linkedNode).getFirstLinkAt(GateTypesIF.GT_SUR) == null) {
                    toDelete.add(linkedNode);
                }
            }
            if(structure.findEntity(currentNode).getFirstLinkAt(GateTypesIF.GT_RET) != null) {
            	currentNode = structure.findEntity(currentNode).getFirstLinkAt(GateTypesIF.GT_RET).getLinkedEntityID();
            } else {
            	break;
            }
        }
        for(int i = 0; i < toDelete.size(); i++) {
            try {
                if(toDelete.get(i) != null)
                    deleteNode((String)toDelete.get(i));
            } catch (NetIntegrityException e) {
                e.printStackTrace();
            }
        }
    }
    
    private void deleteNode(String ID) throws NetIntegrityException {
        structure.deleteEntity(structure.findEntity(ID).getLink(GateTypesIF.GT_SUB, 1).getLinkedEntityID());
        structure.deleteEntity(structure.findEntity(ID).getLink(GateTypesIF.GT_SUB, 0).getLinkedEntityID());
        structure.deleteEntity(ID);
    }
    
    private void addDamageNode(String ID) throws NetIntegrityException {
    	if(lastInsertedDamage != null) {
    		if(NodeFunctions.getPosition(structure.findEntity(ID)).distance2D(lastInsertedDamage) < 0.25)
    			return;
    	}
    	ConceptNode damage = (ConceptNode)structure.findEntity(damageConcept);
    	int numberOfNodes = damage.getGate(GateTypesIF.GT_SUB).getNumberOfLinks();
    	Position testPosition = NodeFunctions.getPosition(structure.findEntity(ID));
    	for(int i = 0; i < numberOfNodes; i++) {
    		if(testPosition.distance2D(NodeFunctions.getPosition(damage.getLink(GateTypesIF.GT_SUB, i).getLinkedEntity())) < 0.25)
	    			return;
    	}
    	structure.createLink(damageConcept, GateTypesIF.GT_SUB, ID, SlotTypesIF.ST_GEN, 1.0, 1.0);
        structure.createLink(ID, GateTypesIF.GT_SUR, damageConcept, SlotTypesIF.ST_GEN, 1.0, 1.0);
        lastInsertedDamage = testPosition;
    }
    
    private void addObstacleNode(String ID) throws NetIntegrityException {
    	if(lastInsertedObstacle != null) {
    		if(NodeFunctions.getPosition(structure.findEntity(ID)).distance2D(lastInsertedObstacle) < 0.25)
    			return;
    	}
    	ConceptNode obstacle = (ConceptNode)structure.findEntity(obstacleConcept);
    	int numberOfNodes = obstacle.getGate(GateTypesIF.GT_SUB).getNumberOfLinks();
    	Position testPosition = NodeFunctions.getPosition(structure.findEntity(ID));
    	for(int i = 0; i < numberOfNodes; i++) {
    		if(testPosition.distance2D(NodeFunctions.getPosition(obstacle.getLink(GateTypesIF.GT_SUB, i).getLinkedEntity())) < 0.25)
	    			return;
    	}
    	structure.createLink(obstacleConcept, GateTypesIF.GT_SUB, ID, SlotTypesIF.ST_GEN, 1.0, 1.0);
        structure.createLink(ID, GateTypesIF.GT_SUR, obstacleConcept, SlotTypesIF.ST_GEN, 1.0, 1.0);
        lastInsertedObstacle = testPosition;
    }
}
