/*
 * Created on 29.04.2005
 *
 */
package org.micropsi.nodenet.modules;

import java.util.ArrayList;

import org.micropsi.common.coordinates.Position;
import org.micropsi.common.coordinates.WorldVector;
import org.micropsi.comp.ConstantValues;
import org.micropsi.nodenet.AbstractNativeModuleImpl;
import org.micropsi.nodenet.ConceptNode;
import org.micropsi.nodenet.GateManipulator;
import org.micropsi.nodenet.GateTypesIF;
import org.micropsi.nodenet.Link;
import org.micropsi.nodenet.NetIntegrityException;
import org.micropsi.nodenet.Slot;
import org.micropsi.nodenet.agent.TypeStrings;
import org.micropsi.nodenet.agent.TypeStringsExtensionIF;

/**
 * @author Markus
 *
 */
public class PlanningModule extends AbstractNativeModuleImpl {

    //TODO get this fronm the world
    private static final double WORLDMAXX = 100;
    private static final double WORLDMAXY  =100;
    
    // slots
    private static final int XCOORDINATE     = 16500;
	private static final int YCOORDINATE     = 16501;
	private static final int FOODURGE	     = 16502;
	private static final int WATERURGE       = 16503;
	private static final int HEALINGURGE     = 16504;
	private static final int AFFILIATIONURGE = 16505;
    
    // gates
    private static final int XGOAL = 16500;
    private static final int YGOAL = 16501;
    private static final int RANDOM = 16502; // if there is no goal, randommovement
	private static final int FOODCONCEPT = 16503;
	private static final int WATERCONCEPT = 16504;
	private static final int HEALINGCONCEPT = 16505;
	private static final int HURTCONCEPT = 16506;
	private static final int OBSTACLECONCEPT = 16507;
	private static final int PROTOCOL = 16508;
	private static final int NOPROTOCOL = 16509;
	private static final int CURRENTGOAL = 165010;
 
    
    private Slot x;
	private Slot y;
	private Slot food;
	private Slot water;
	private Slot healing;
	private Slot hurt;
	private Slot affiliation;
	
	private ConceptNode foodConcept = null;
	private ConceptNode waterConcept = null;
	private ConceptNode healingConcept = null;
	private ConceptNode damageConcept = null;
	private ConceptNode obstacleConcept = null;
	
	private boolean firsttime = true;
	private int currentMotive = 0;
	private String goalID = null;
	
	private boolean onTheWay = false;
	
	public PlanningModule() {	
		TypeStrings.activateExtension(new TypeStringsExtensionIF() {

			private static final String id = "planning";

			public String getExtensionID() {
				return id;
			}

			public String gateType(int type) {
			    switch(type) {
			    	case XGOAL: return "x-goal";
			    	case YGOAL: return "y-goal";
			    	case RANDOM: return "random-movement";
			    	case FOODCONCEPT: return "food-concept";
			    	case WATERCONCEPT: return "water-concept";
			    	case HEALINGCONCEPT: return "healing-concept";
			    	case HURTCONCEPT: return "damage-concept";
			    	case OBSTACLECONCEPT: return "obstacle-concept";
			    	case PROTOCOL: return "protocol-module";
			    	case NOPROTOCOL: return "no-protocolling";
			    	case CURRENTGOAL: return "current-goalnode";
			    	default:    return null;
			    }
			}

			public String slotType(int type) {
				switch(type) {
					case XCOORDINATE: return "x-position";
					case YCOORDINATE: return "y-position";
					case FOODURGE: return "food-urge";
					case WATERURGE:	return "water-urge";
					case HEALINGURGE: return "healing-urge";
					case AFFILIATIONURGE: return "affiliation-urge";
					default:			return null;
				}
			}
		});		
	}
	
	private final int[] slotTypes = {
	        XCOORDINATE,
	        YCOORDINATE,
	        FOODURGE,
	        WATERURGE,
	        HEALINGURGE,
	        AFFILIATIONURGE
		};
	
	private final int[] gateTypes = {
	        XGOAL,
	        YGOAL,
	        RANDOM,
			FOODCONCEPT,
			WATERCONCEPT,
			HEALINGCONCEPT,
			HURTCONCEPT,
			OBSTACLECONCEPT,
			PROTOCOL,
			NOPROTOCOL,
			CURRENTGOAL
	};
    
    /* (non-Javadoc)
     * @see org.micropsi.nodenet.AbstractNativeModuleImpl#getGateTypes()
     */
    protected int[] getGateTypes() {
        return gateTypes;
    }

    /* (non-Javadoc)
     * @see org.micropsi.nodenet.AbstractNativeModuleImpl#getSlotTypes()
     */
    protected int[] getSlotTypes() {
        return slotTypes;
    }

    private void catchSlots(Slot[] slots) {
		for (int i = 0; i < slots.length; i++) {
			switch (slots[i].getType()) {
				case XCOORDINATE :
					x = slots[i];
					break;
				case YCOORDINATE : 
					y = slots[i];
					break;
			    case FOODURGE :
			        food = slots[i];
			        break;
			    case WATERURGE :
			        water = slots[i];
			        break;
			    case HEALINGURGE :
			        healing = slots[i];
			        break;
			    case AFFILIATIONURGE:
			        affiliation = slots[i];
			}
		}
	}
    
    /* (non-Javadoc)
     * @see org.micropsi.nodenet.AbstractNativeModuleImpl#calculate(org.micropsi.nodenet.Slot[], org.micropsi.nodenet.GateManipulator, long)
     */
    public void calculate(Slot[] slots, GateManipulator manipulator, long netstep) throws NetIntegrityException {
        if (firsttime) {
			catchSlots(slots);
			firsttime = false;
			
			Link l = manipulator.getGate(FOODCONCEPT).getLinkAt(0);
			if(l == null)
				logger.warn("protocol has no link to foodconcept");
			else
				foodConcept = (ConceptNode)l.getLinkedEntity();
			
			l = manipulator.getGate(WATERCONCEPT).getLinkAt(0);
			if(l == null)
				logger.warn("protocol has no link to waterconcept");
			else
				waterConcept = (ConceptNode)l.getLinkedEntity();
			
			l = manipulator.getGate(HEALINGCONCEPT).getLinkAt(0);
			if(l == null)
				logger.warn("protocol has no link to healingconcept");
			else
				healingConcept = (ConceptNode)l.getLinkedEntity();
			
			l = manipulator.getGate(HURTCONCEPT).getLinkAt(0);
			if(l == null)
				logger.warn("protocol has no link to damageconcept");
			else
				damageConcept = (ConceptNode)l.getLinkedEntity();
			
			l = manipulator.getGate(OBSTACLECONCEPT).getLinkAt(0);
			if(l == null)
				logger.warn("protocol has no link to obstacleconcept");
			else
				obstacleConcept = (ConceptNode)l.getLinkedEntity();
		}
        Position currentPosition = NodeFunctions.getPosition(x.getIncomingActivation(), y.getIncomingActivation());
        manipulator.setGateActivation(RANDOM, 0.0);
        
        // calculate motive
        //TODO consider competence
        int newMotive = 0;
        double newMotiveStrength = 0.0;
        double oldMotiveStrength = 0.0;
        for(int i = 2; i < slots.length; i++) {
            if(slots[i].getIncomingActivation() > newMotiveStrength) {
                newMotive = slots[i].getType();
                newMotiveStrength = slots[i].getIncomingActivation();
            }
            if(slots[i].getType() == currentMotive) {
                oldMotiveStrength = slots[i].getIncomingActivation();
            }
        }
        if(currentMotive == 0) {         
            currentMotive = newMotive;
            goalID = null;
            onTheWay = false;
        } else {
            if(oldMotiveStrength + ConstantValues.STUBBORNESS < newMotiveStrength) {
                currentMotive = newMotive;
                goalID = null;
                onTheWay = false;
            }
        }
        
        // already have a plan
        if(goalID != null) {
            ConceptNode goal = (ConceptNode)structure.findEntity(goalID);
            if(currentPosition.distance2D(NodeFunctions.getPosition(goal)) < 0.25) {
            	manipulator.setGateActivation(NOPROTOCOL, 1.0);
                if(goal.getFirstLinkAt(GateTypesIF.GT_POR) == null) {
                    goalID = null;
                    onTheWay = false;
                } else {
	                ConceptNode newGoal = (ConceptNode)goal.getFirstLinkAt(GateTypesIF.GT_POR).getLinkedEntity();
	                
	                manipulator.setGateActivation(XGOAL, newGoal.getLink(GateTypesIF.GT_SUB, 0).getWeight());
	                manipulator.setGateActivation(YGOAL, newGoal.getLink(GateTypesIF.GT_SUB, 1).getWeight());
	                goalID = newGoal.getID();
	                onTheWay = true;
                }
            } else if (!onTheWay) {
            	if(isReachable(currentPosition, NodeFunctions.getPosition(goal))) {
            		manipulator.setGateActivation(XGOAL, structure.findEntity(goalID).getLink(GateTypesIF.GT_SUB, 0).getWeight());
            		manipulator.setGateActivation(YGOAL, structure.findEntity(goalID).getLink(GateTypesIF.GT_SUB, 1).getWeight());
            		manipulator.setGateActivation(NOPROTOCOL, 1.0);
            	} else {
            		logger.info("target not reachable");
            		goalID = null;
            		onTheWay = false;
            		manipulator.setGateActivation(RANDOM, 1.0);
            		manipulator.setGateActivation(NOPROTOCOL, 0.0);
            	}
            } else {
            	manipulator.setGateActivation(XGOAL, structure.findEntity(goalID).getLink(GateTypesIF.GT_SUB, 0).getWeight());
        		manipulator.setGateActivation(YGOAL, structure.findEntity(goalID).getLink(GateTypesIF.GT_SUB, 1).getWeight());
        		manipulator.setGateActivation(NOPROTOCOL, 1.0);
            }
        } else {
            manipulator.setGateActivation(NOPROTOCOL, 0.0);
        	if(getMotiveSlot(currentMotive) != null) {
	            if(getMotiveSlot(currentMotive).getIncomingActivation() < 0.05) {
	                manipulator.setGateActivation(RANDOM, 1.0);
	                return;
	            }
        	}
            if(currentMotive == AFFILIATIONURGE) {
                //TODO search agent and smile
                return;
            }
            
            ConceptNode currentMotiveConcept = getConcept(currentMotive);
            if(currentMotiveConcept == null || currentMotiveConcept.getFirstLinkAt(GateTypesIF.GT_SUB) == null) {
                // no planning possible due to lack of information
                manipulator.setGateActivation(RANDOM, 1.0);
                return;
            }
            int numberOfNodes = currentMotiveConcept.getGate(GateTypesIF.GT_SUB).getNumberOfLinks();
            double minDistance = 1000.0;
            for(int i = 0; i < numberOfNodes; i++) {
                Link testLink = currentMotiveConcept.getLink(GateTypesIF.GT_SUB, i);
                if(testLink != null) { 
                    Position testPosition = NodeFunctions.getPosition(testLink.getLinkedEntity());
                    if(currentPosition.distance2D(testPosition) < minDistance && isReachable(currentPosition, testPosition)) {
                        minDistance = currentPosition.distance2D(testPosition);
                        goalID = ((ConceptNode)testLink.getLinkedEntity()).getID();
                    }
                }
            }
            if(goalID == null) {
            	logger.info("no reachable waypoint found");
                manipulator.setGateActivation(RANDOM, 1.0);
                onTheWay = false;
                return;
            } else {
            	//TODO make this more accurate (noprotocol)
                manipulator.setGateActivation(XGOAL, structure.findEntity(goalID).getLink(GateTypesIF.GT_SUB, 0).getWeight());
                manipulator.setGateActivation(YGOAL, structure.findEntity(goalID).getLink(GateTypesIF.GT_SUB, 1).getWeight());
            }
        }
    }
    
    private ConceptNode getConcept(int motive) {
        switch(motive) {
        	case FOODURGE: return foodConcept;
        	case WATERURGE: return waterConcept;
        	case HEALINGURGE: return healingConcept;
        	default: return null;
        }
    }
    
    private Slot getMotiveSlot(int motive) {
        switch(motive) {
        	case FOODURGE: return food;
        	case WATERURGE: return water;
        	case HEALINGURGE: return healing;
        	case AFFILIATIONURGE: return affiliation;
        	default: return null;
        }
    }
    
    private boolean isReachable(Position currentPos, Position goalPos) {
    	ArrayList potentialObstacles = new ArrayList();
    	int numberOfNodes;
    	int counter = 0;
    	int i;
    	if(damageConcept != null) {
	    	numberOfNodes = damageConcept.getGate(GateTypesIF.GT_SUB).getNumberOfLinks();
	    	for(i = 0; i < numberOfNodes; i++) {
	    		potentialObstacles.add(damageConcept.getLink(GateTypesIF.GT_SUB, i).getLinkedEntityID());
	    		counter++;
	    	}
    	}
    	if(obstacleConcept != null) {
    		numberOfNodes = obstacleConcept.getGate(GateTypesIF.GT_SUB).getNumberOfLinks();
    		for(i = 0; i < numberOfNodes; i++) {
	    		potentialObstacles.add(obstacleConcept.getLink(GateTypesIF.GT_SUB, i).getLinkedEntityID());
	    		counter++;
	    	}
    	}
    	
    	if(counter > 0) {
    		WorldVector goalVector = new WorldVector(goalPos.getX() - currentPos.getX(), goalPos.getY() - currentPos.getY(), 0.0);
    		WorldVector testVector;
    		Position testPosition;
    		double angle;
    		for(i = 0; i < potentialObstacles.size(); i++) {
    			if(potentialObstacles.get(i) != null) {
    				testPosition = NodeFunctions.getPosition(structure.findEntity((String)potentialObstacles.get(i)));
    				// obstacle belongs to way
    				if(testPosition.distance2D(goalPos) <= 0.25)
    					continue;
    				testVector = new WorldVector(testPosition.getX() - currentPos.getX(), testPosition.getY() - currentPos.getY(), 0.0);
    				angle = Math.abs(goalVector.getAngle() - testVector.getAngle());
    		    	if(angle > 180.0)
    		    		angle -= 180.0;
    		    	if(angle > 90.0)
    		    		continue;
    		    	WorldVector normGoalVector = new WorldVector(goalVector);
    		    	normGoalVector.setLength(1.0);
    				if(scalarProduct(normGoalVector, testVector) > goalVector.getLength())
    					continue;
    				else {
    					WorldVector normalVector = new WorldVector(goalVector.getY(), goalVector.getX(), 0.0);
    					normalVector.setLength(1.0);
    					if(Math.abs(scalarProduct(normalVector, testVector)) <= 0.5) {
    						return false;
    					}
    					normalVector.scaleBy(-1.0);
    					if(Math.abs(scalarProduct(normalVector, testVector)) <= 0.5) {
    						return false;
    					}
    				}
    			}
    		}
    	}
    	return true;
    }
    
    private double scalarProduct(WorldVector vec1, WorldVector vec2) {
    	/*
    	double angle = Math.abs(vec1.getAngle() - vec2.getAngle());
    	if(angle > 180.0)
    		angle -= 180.0;
		return Math.cos(Math.toRadians(angle)) * vec1.getLength() * vec2.getLength();
		*/
    	return vec1.getX() * vec2.getX() + vec1.getY() * vec2.getY();
    }
}
