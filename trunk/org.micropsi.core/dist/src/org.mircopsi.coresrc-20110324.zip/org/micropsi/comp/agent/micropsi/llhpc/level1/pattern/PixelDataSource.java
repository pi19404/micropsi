package org.micropsi.comp.agent.micropsi.llhpc.level1.pattern;

public class PixelDataSource {

	public PixelDataSource() {
		super();
		// TODO Auto-generated constructor stub
	}

}
