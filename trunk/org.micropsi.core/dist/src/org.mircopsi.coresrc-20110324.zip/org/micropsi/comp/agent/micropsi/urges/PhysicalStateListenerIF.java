package org.micropsi.comp.agent.micropsi.urges;

/**
 * 
 * 
 * 
 */
public interface PhysicalStateListenerIF {

	public void die(String reason);

}
