/**
 * $Header: G:\DEV\Workspace\migration3.0\micropsi-cvs-repository\micropsi/org.micropsi.core/sources/org/micropsi/comp/agent/AgentTypesIF.java,v 1.3 2005/05/07 02:19:28 jbach Exp $
 */
package org.micropsi.comp.agent;

public interface AgentTypesIF {
	
	public static final int AGENT_TESTAGENT = 0;
	public static final int AGENT_MICROPSI_STANDARD = 1;
	public static final int AGENT_MICROPSI_TURTLE = 2;
	public static final int AGENT_MICROPSI_OMNI = 3;

}
