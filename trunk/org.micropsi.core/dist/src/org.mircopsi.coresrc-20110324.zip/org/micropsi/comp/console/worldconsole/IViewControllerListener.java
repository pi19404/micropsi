/*
 * $Header: G:\DEV\Workspace\migration3.0\micropsi-cvs-repository\micropsi/org.micropsi.core/sources/org/micropsi/comp/console/worldconsole/IViewControllerListener.java,v 1.1 2005/04/25 19:55:33 fuessel Exp $ 
 */
package org.micropsi.comp.console.worldconsole;


/**
 * Copied from org.micropsi.console project for now. Will probably be rewritten.
 */
public interface IViewControllerListener {

	public void setDataBase(Object o);
	
	public void setData(Object o);

}
