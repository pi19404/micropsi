/**
 * $Header: G:\DEV\Workspace\migration3.0\micropsi-cvs-repository\micropsi/org.micropsi.core/sources/org/micropsi/comp/agent/CycleSignalsIF.java,v 1.2 2004/08/10 14:38:17 fuessel Exp $
 */
package org.micropsi.comp.agent;

public interface CycleSignalsIF {

	public static final int CYCLE_SIGNAL_HALFTIME = 0;
	public static final int CYCLE_SIGNAL_TENPERCENT = 1;
	public static final int CYCLE_SIGNAL_NEWDATA = 2;

}
