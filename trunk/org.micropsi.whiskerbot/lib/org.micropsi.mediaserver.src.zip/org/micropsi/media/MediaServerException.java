package org.micropsi.media;

public class MediaServerException extends Exception {

	public MediaServerException() {
		super();
	}

	public MediaServerException(String arg0) {
		super(arg0);
	}

	public MediaServerException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public MediaServerException(Throwable arg0) {
		super(arg0);
	}

}
