/*
 * $Header: /var/cvs/micropsi/org.micropsi.core/sources/org/micropsi/nodenet/outputfunctions/OFBandpass.java,v 1.2 2006/06/27 19:37:54 rvuine Exp $ 
 */
package org.micropsi.nodenet.outputfunctions;

import org.micropsi.nodenet.OutputFunctionIF;
import org.micropsi.nodenet.OutputFunctionParameter;

/** 
 * Bandpass threshold: f(x) = x, if (x >= theta and x <= 1-theta), 0 else
 * Note that normally, theta should be a value between 0 and 0.5
 */
public class OFBandpass implements OutputFunctionIF {

	/*(non-Javadoc)
	 * @see org.micropsi.nodenet.OutputFunctionIF#getDisplayName()
	 */
	public String getDisplayName() {
		return "Bandpass";
	}

	/*(non-Javadoc)
	 * @see org.micropsi.nodenet.OutputFunctionIF#getParameters()
	 */
	public OutputFunctionParameter[] constructEmptyParameters() {
		return new OutputFunctionParameter[] {
			new OutputFunctionParameter("theta"),
		};
	}

	/*
	 * (non-Javadoc)
	 * @see org.micropsi.nodenet.OutputFunctionIF#calculate(double, double, org.micropsi.nodenet.OutputFunctionParameter[])
	 */
	public double calculate(double value, double lastCycleResult, OutputFunctionParameter[] params) {
		double theta = params[0].getValue();
		
		if (value>=theta && value <= 1-theta) {
			return value;
		} else {
			return 0;
		} 
	}
}
