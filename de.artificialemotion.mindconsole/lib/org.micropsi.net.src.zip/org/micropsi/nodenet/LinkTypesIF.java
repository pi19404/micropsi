/**
 * $Header: /var/cvs/micropsi/org.micropsi.core/sources/org/micropsi/nodenet/LinkTypesIF.java,v 1.2 2004/08/10 14:38:16 fuessel Exp $
 */
package org.micropsi.nodenet;

/**
 * The technical types of links
 */
public interface LinkTypesIF {

	public static final int LINKTYPE_SIMPLEASSOCIATION = 0;
	public static final int LINKTYPE_SPACIOTEMPORAL = 1;

}
