package org.micropsi.nodenet.agent;

/**
 * 
 * 
 * 
 */
public interface TypeStringsExtensionIF {

	public String getExtensionID();
	
	public String gateType(int type);
	
	public String slotType(int type);

}
